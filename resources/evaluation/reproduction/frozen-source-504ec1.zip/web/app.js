'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const state = {session: null, memory: null, searchController: null, searchNumber: 0, busy: false};
  const node = (tag, text, cls) => { const el = document.createElement(tag); if (text != null) el.textContent = text; if (cls) el.className = cls; return el; };
  const id = () => globalThis.crypto?.randomUUID?.() || `request_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  async function api(path, options = {}) {
    const response = await fetch(path, {...options, headers: {'Content-Type': 'application/json', ...options.headers}});
    if (response.status === 204) return null;
    const body = await response.json().catch(() => ({}));
    if (!response.ok) { const error = new Error(body.message || `Request failed (${response.status})`); error.status = response.status; throw error; }
    return body;
  }
  function showMemory(memory) {
    state.memory = memory;
    $('memory').textContent = `${memory.shortlisted_person_ids.length} shortlisted · ${memory.rejected_person_ids.length} rejected${memory.last_query ? ` · Last search: ${memory.last_query}` : ''}`;
  }
  async function start() {
    try { const session = await api('/sessions', {method: 'POST'}); state.session = session.session_id; showMemory(session.memory); }
    catch (error) { $('memory').textContent = `Could not start a session: ${error.message}`; }
  }
  async function syncMemory() { if (!state.session) throw new Error('Session unavailable. Reload the page.'); showMemory(await api(`/sessions/${state.session}/memory`)); }
  async function mutate(path, method, fields, signal) {
    if (!state.session) throw new Error('Session unavailable. Reload the page.');
    let requestId = id();
    for (let attempt = 0; attempt < 2; attempt++) {
      const body = JSON.stringify({...fields, expected_version: state.memory.version, request_id: requestId});
      try { const result = await api(path, {method, body, signal}); if (result?.memory) showMemory(result.memory); return result; }
      catch (error) {
        if (error.name === 'AbortError') throw error;
        if (error.status === 409 && attempt === 0) { await syncMemory(); requestId = id(); continue; }
        if (!error.status && attempt === 0) {
          // An exact retry is idempotent if the response was lost after commit.
          try { const result = await api(path, {method, body, signal}); if (result?.memory) showMemory(result.memory); return result; }
          catch (retry) { if (retry.name === 'AbortError') throw retry; error = retry; }
        }
        await syncMemory().catch(() => {}); throw error;
      }
    }
  }
  function message(text, who, tools = [], applied = null) {
    const bubble = node('div', null, `bubble ${who}`); bubble.append(node('span', who === 'user' ? 'YOU' : 'ASSISTANT'), node('p', text));
    if (tools.length) bubble.append(node('div', `Tools: ${tools.map(t => `${t.tool} ${JSON.stringify(t.arguments)} (${t.outcome})`).join(', ')}`, 'tool-list'));
    if (applied) bubble.append(node('div', `Memory applied: ${applied.shortlisted_person_ids.length} shortlisted, ${applied.rejected_person_ids.length} rejected${applied.last_query ? `; last search: ${applied.last_query}` : ''}`, 'tool-list'));
    $('chat').append(bubble); $('chat').scrollTop = $('chat').scrollHeight;
  }
  function errorStatus(text) { $('search-status').textContent = text; $('search-status').classList.add('error'); }
  function renderResults(results) {
    $('results').replaceChildren(); $('profile').hidden = true;
    $('results-title').textContent = results.length ? 'People worth exploring' : 'No matching experts';
    $('result-count').textContent = results.length ? `${results.length} RESULTS` : '';
    $('search-status').textContent = results.length ? 'Ranked using historical research evidence. Scores are relative ranking values.' : 'Try a broader or different research topic.';
    $('search-status').classList.remove('error');
    for (const person of results) {
      const card = node('article', null, 'result'); const avatar = node('div', person.name.slice(0, 1).toUpperCase(), 'avatar');
      const content = node('div'); const top = node('div', null, 'result-top');
      top.append(node('h4', person.name), node('span', `SCORE ${Number(person.score).toFixed(3)}`, 'score')); content.append(top, node('p', person.explanation));
      const actions = node('div', null, 'result-actions');
      for (const [label, value] of [['Shortlist', 'shortlist'], ['Reject', 'reject']]) {
        const selected = value === 'shortlist' ? state.memory?.shortlisted_person_ids.includes(person.person_id) : state.memory?.rejected_person_ids.includes(person.person_id);
        const button = node('button', label, `small-btn${selected ? ' active' : ''}`); button.type = 'button'; button.dataset.decision = value;
        button.addEventListener('click', async () => {
          if (state.busy) return; state.busy = true; button.disabled = true;
          try { await mutate(`/sessions/${state.session}/decisions/${person.person_id}`, 'PUT', {decision: value});
            for (const control of actions.querySelectorAll('[data-decision]')) control.classList.toggle('active', control.dataset.decision === value);
            message(`${person.name}: ${value} saved.`, 'assistant'); }
          catch (error) { message(`Could not save decision: ${error.message}`, 'assistant'); }
          finally { state.busy = false; button.disabled = false; }
        }); actions.append(button);
      }
      const profileButton = node('button', 'View profile ↗', 'small-btn'); profileButton.type = 'button';
      profileButton.addEventListener('click', async () => {
        try { const profile = await api(`/authors/${person.person_id}`); const area = $('profile'); area.replaceChildren();
          area.append(node('span', 'PUBLICATION PROFILE', 'eyebrow muted'), node('h3', profile.name));
          area.append(node('p', `Topics: ${profile.topics.map(t => `${t.topic} [${t.source_paper_ids.join(', ')}]`).join('; ') || 'No topics available'}`));
          const list = node('ul'); for (const p of profile.publications) list.append(node('li', `${p.year || 'Year unknown'} · ${p.title} · ${p.venue || 'Venue unavailable'} · ${p.source} / ${p.paper_id}`));
          area.append(list); area.hidden = false; area.scrollIntoView({behavior: 'smooth', block: 'start'});
        } catch (error) { errorStatus(`Could not load profile: ${error.message}`); }
      }); actions.append(profileButton); content.append(actions);
      const details = node('details'); details.append(node('summary', `View ${person.evidence.length} supporting papers`));
      for (const paper of person.evidence) { const block = node('div', null, 'evidence'); block.append(node('strong', paper.title), node('div', `${paper.year || 'Year unknown'} · ${paper.source} / ${paper.paper_id}`), node('div', `With: ${paper.collaborators.map(c => c.name).join(', ') || 'No collaborators listed'}`)); details.append(block); }
      for (const claim of person.claims || []) if (!claim.supported) details.append(node('p', `Unsupported claim: ${claim.text}`, 'warning'));
      content.append(details); card.append(avatar, content); $('results').append(card);
    }
  }
  async function search(query) {
    if (!query.trim()) return;
    const number = ++state.searchNumber; if (state.searchController) state.searchController.abort();
    const controller = new AbortController(); state.searchController = controller;
    $('search-status').classList.remove('error'); $('search-status').textContent = 'Searching the research graph…';
    try {
      await syncMemory();
      const result = await mutate('/search', 'POST', {query: query.trim(), limit: 10, session_id: state.session}, controller.signal);
      if (number === state.searchNumber) renderResults(result.results);
    } catch (error) { if (error.name !== 'AbortError' && number === state.searchNumber) errorStatus(`Search failed: ${error.message}`); }
  }
  $('search-form').addEventListener('submit', event => { event.preventDefault(); search($('query').value); });
  for (const hint of document.querySelectorAll('.hint')) hint.addEventListener('click', () => { $('query').value = hint.dataset.query; search(hint.dataset.query); });
  $('chat-form').addEventListener('submit', async event => {
    event.preventDefault(); const text = $('message').value.trim(); if (!text || state.busy) return;
    state.busy = true; $('message').value = ''; message(text, 'user');
    try { await syncMemory(); const result = await mutate(`/sessions/${state.session}/messages`, 'POST', {message: text}); message(result.message, 'assistant', result.tool_calls, result.memory_applied); if (result.results.length) renderResults(result.results); if (result.profile) { const p = result.profile; message(`${p.name}: ${p.publications.length} sourced publications.`, 'assistant'); } }
    catch (error) { message(`Could not complete that request: ${error.message}`, 'assistant'); }
    finally { state.busy = false; }
  });
  $('clear-memory').addEventListener('click', async () => { if (state.busy) return; state.busy = true;
    try { await syncMemory(); await mutate(`/sessions/${state.session}/memory`, 'DELETE', {}); message('Session memory cleared.', 'assistant'); }
    catch (error) { message(`Could not clear memory: ${error.message}`, 'assistant'); } finally { state.busy = false; }
  });
  start();
})();
