"""Typed failures shared by the backend, session store, and HTTP boundary."""


class BackendError(Exception):
    def __init__(self, code, message, status=400):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)
