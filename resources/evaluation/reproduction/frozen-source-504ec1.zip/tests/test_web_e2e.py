"""Real browser smoke test of search, shortlist, assistant, and safe rendering."""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
CHROMEDRIVER = shutil.which('chromedriver')
CHROMIUM = shutil.which('chromium') or shutil.which('google-chrome')


def free_port():
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        return listener.getsockname()[1]


@unittest.skipUnless(CHROMEDRIVER and CHROMIUM, 'Chromium and chromedriver are needed for browser E2E')
class BrowserTests(unittest.TestCase):
    def test_search_shortlist_and_assistant(self):
        with tempfile.TemporaryDirectory(prefix='hiresense-browser-') as tmp:
            env = dict(os.environ, PYTHONPATH=str(ROOT / 'src'))
            prepared = Path(tmp) / 'backend'
            result = subprocess.run([sys.executable, '-m', 'hiresense.cli', 'prepare-backend', '--data',
                                     str(ROOT / 'examples/sample.xml'), '--out', str(prepared)],
                                    cwd=ROOT, env=env, capture_output=True, text=True, timeout=40)
            self.assertEqual(result.returncode, 0, result.stderr)
            app_port, driver_port = free_port(), free_port()
            app = subprocess.Popen([sys.executable, '-m', 'hiresense.cli', 'serve', '--config',
                                    str(prepared / 'backend.json'), '--port', str(app_port)],
                                   cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            driver = subprocess.Popen([CHROMEDRIVER, f'--port={driver_port}', '--allowed-ips=127.0.0.1'],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            session = None
            base = f'http://127.0.0.1:{driver_port}'
            try:
                with httpx.Client(timeout=20, trust_env=False) as client:
                    def wait_for(predicate, seconds=30):
                        until = time.monotonic() + seconds
                        while time.monotonic() < until:
                            try:
                                value = predicate()
                                if value:
                                    return value
                            except (httpx.HTTPError, KeyError):
                                pass
                            time.sleep(.15)
                        self.fail('Timed out waiting for browser or application')
                    wait_for(lambda: client.get(f'http://127.0.0.1:{app_port}/health').status_code == 200)
                    wait_for(lambda: client.get(base + '/status').status_code == 200)
                    response = client.post(base + '/session', json={'capabilities': {'alwaysMatch': {
                        'browserName': 'chrome', 'goog:chromeOptions': {'binary': CHROMIUM,
                            'args': ['--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--no-proxy-server']}}}})
                    self.assertEqual(response.status_code, 200, response.text)
                    session = response.json()['value']['sessionId']
                    prefix = base + '/session/' + session
                    def execute(script):
                        response = client.post(prefix + '/execute/sync', json={'script': script, 'args': []})
                        self.assertEqual(response.status_code, 200, response.text)
                        return response.json()['value']
                    response = client.post(prefix + '/url', json={'url': f'http://127.0.0.1:{app_port}/'})
                    self.assertEqual(response.status_code, 200, response.text)
                    wait_for(lambda: 'shortlisted' in execute("return document.querySelector('#memory').textContent"))
                    self.assertTrue(execute("return !!document.querySelector('label[for=query]')"))
                    execute("document.querySelector('#query').value='remote sensing image classification'; document.querySelector('#search-form').requestSubmit(); document.querySelector('#query').value='graph neural networks hardware acceleration'; document.querySelector('#search-form').requestSubmit();")
                    wait_for(lambda: execute("return document.querySelectorAll('.result').length") > 0)
                    self.assertIn('graph neural networks hardware acceleration', execute("return document.querySelector('#memory').textContent"))
                    self.assertTrue(execute("return document.querySelector('.result details summary').textContent.includes('supporting papers')"))
                    execute("document.querySelector('.result details summary').click()")
                    self.assertTrue(execute("return document.querySelector('.result details').open"))
                    execute("document.querySelectorAll('.result .small-btn')[2].click()")
                    wait_for(lambda: execute("return !document.querySelector('#profile').hidden"))
                    self.assertTrue(execute("return document.querySelector('#profile').textContent.includes('dblp')"))
                    execute("document.querySelector('.result .small-btn').click()")
                    wait_for(lambda: '1 shortlisted' in execute("return document.querySelector('#memory').textContent"))
                    execute("document.querySelector('#message').value='show shortlist'; document.querySelector('#chat-form').requestSubmit()")
                    wait_for(lambda: 'get_profile' in execute("return document.querySelector('#chat').textContent"))
                    self.assertTrue(execute("return document.querySelector('#chat').textContent.includes('Showing 1')"))
                    self.assertTrue(execute("return document.querySelector('#chat').textContent.includes('Memory applied: 1 shortlisted')"))
                    execute("document.querySelector('#clear-memory').click()")
                    wait_for(lambda: '0 shortlisted' in execute("return document.querySelector('#memory').textContent"))
            finally:
                if session:
                    try:
                        httpx.delete(base + '/session/' + session, timeout=3, trust_env=False)
                    except httpx.HTTPError:
                        pass
                for process in (driver, app):
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)


if __name__ == '__main__':
    unittest.main()
